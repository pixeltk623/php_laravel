<?php 
	define('BASE_URL', 'http://localhost/php_21_sep/mvc/');
?>